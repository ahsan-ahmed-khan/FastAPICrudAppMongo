from pydantic import BaseModel


class node(BaseModel):
    title: str
    desc: str
    important: bool = None


class getNode(BaseModel):
    id : str
    title: str
    desc: str
    important: bool = None