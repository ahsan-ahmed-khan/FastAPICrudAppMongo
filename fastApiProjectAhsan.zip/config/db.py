from pymongo import MongoClient

MONGO_URI = "localhost:27017"

client = MongoClient(MONGO_URI)
db = client["nodes"]
collection = db["nodes"]
