from models.Node import *


def nodeEntity(item):
    return getNode(
        id = str(item["_id"]),
        title = item["title"],
        desc = item["desc"],
        important = item["important"]
    )


def nodesEntity(items) -> list:
    return [nodeEntity(x) for x in items]