from bson import ObjectId
from fastapi import APIRouter, FastAPI, Request
from models.Node import node
from config.db import collection
from schemas.node import nodeEntity, nodesEntity

Node = APIRouter()

@Node.get("/blog")
def read_blog():
    docs = collection.find({})
    new_docs = []
    for doc in docs:
        new_doc = node(
            id = str(doc["_id"]),
            title = doc["title"],
            desc = doc["desc"]
        )
        new_docs.append(new_doc)
    return {"data": new_docs}


@Node.post("/insert_nodes")
def insert_blog(nodes : node):
    inserted_node = collection.insert_one(dict(nodes))
    inserted_node_data = collection.find_one({"_id": ObjectId(inserted_node.inserted_id)})

    return {"data" : dict(nodes)}